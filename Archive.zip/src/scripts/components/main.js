import './navbar';
import './hero';
import './footer';
